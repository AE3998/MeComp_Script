function x = f_test(z)
  x = z(1);  
endfunction